<?php 
	return $confg = array(
"host"=>"localhost:3306",  
"user"=>"root",  
"pwd" =>"root",             
"db_name" =>"db_up",            
"tb_name" =>"tb_game",            
);